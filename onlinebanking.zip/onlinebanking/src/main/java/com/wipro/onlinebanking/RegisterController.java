package com.wipro.onlinebanking;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins="http://localhost:4200")
@RestController

public class RegisterController {
	@Autowired
    private RegisterService registerService;

    @GetMapping("/register")
    public ResponseEntity < List < Register >> getAllRegister() {
        return ResponseEntity.ok().body(registerService.getAllRegister());
    }

    @GetMapping("/register/{userid}")
    public ResponseEntity < Register > getRegisterById(@PathVariable String userid) {
        return ResponseEntity.ok().body(registerService.getRegisterById(userid));
    }

    @PostMapping("/register")
    public ResponseEntity < Register > createRegister(@RequestBody Register register) {
        return ResponseEntity.ok().body(this.registerService.createRegister(register));
    }

    @PutMapping("/register/{userid}")
    public ResponseEntity < Register > updateRegister(@PathVariable String userid, @RequestBody Register register) {
        register.setUserid(userid);
        return ResponseEntity.ok().body(this.registerService.updateRegister(register));
    }
}
