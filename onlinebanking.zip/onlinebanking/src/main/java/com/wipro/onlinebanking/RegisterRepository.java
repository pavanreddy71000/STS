package com.wipro.onlinebanking;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RegisterRepository extends MongoRepository < Register, String >{

}
